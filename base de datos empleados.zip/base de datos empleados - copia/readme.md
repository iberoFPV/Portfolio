# Lista de empleados

Este es un proyecto de lista de empleados que utiliza Flask como framework web. Permite agregar nuevos empleados, actualizar sus salarios y muestra una lista de empleados registrados.

## Requisitos

- Python 3.7 o superior.
- Flask instalado. Si no tienes Flask instalado, puedes instalarlo utilizando el siguiente comando:

  ```shell
  pip install flask
  ```

## Ejecución

1. Clona el repositorio o descarga los archivos.

2. En la terminal, navega al directorio del proyecto.

3. Ejecuta el siguiente comando para iniciar la aplicación:

   ```shell
   python nombre_del_archivo.py
   ```

   Asegúrate de reemplazar `nombre_del_archivo.py` con el nombre real del archivo Python que contiene el código de la aplicación Flask.

4. Abre tu navegador web y visita la siguiente dirección URL:

   ```
   http://localhost:5000
   ```

   Aquí podrás ver y utilizar la lista de empleados.

## Estructura de archivos

- El archivo `nombre_del_archivo.py` contiene el código de la aplicación Flask.

- La carpeta `/static` contiene los archivos estáticos de la aplicación, incluyendo la hoja de estilos CSS.

- El archivo `normalize_ok.css` en el directorio raíz es utilizado para normalizar los estilos en diferentes navegadores.

## Contribuciones

Si deseas contribuir a este proyecto, siéntete libre de hacerlo. Puedes abrir un Pull Request con tus mejoras o correcciones.

## Autor

- [Nombre del autor](https://github.com/iberoFPV)

## Licencia

Este proyecto está bajo la [Licencia MIT](LICENSE).
