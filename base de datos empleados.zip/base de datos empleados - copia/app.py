from flask import Flask, render_template, request

app = Flask(__name__)
app.static_folder = 'static'


empleados = []  # Lista para almacenar los empleados

@app.route('/')
def index():
    return render_template('index.html', empleados=empleados)
    # Renderiza la plantilla 'index.html' y pasa la lista de empleados como argumento

@app.route('/agregar_empleado', methods=['POST'])
def agregar_empleado():
    nombre = request.form['nombre']  # Obtener nombre del formulario
    salario = float(request.form['salario'])  # Obtener salario del formulario
    departamento = request.form['departamento']  # Obtener departamento del formulario
    
    empleado = {"nombre": nombre, "salario": salario, "departamento": departamento}
    # Crear un diccionario con los datos del empleado
    
    empleados.append(empleado)  # Agregar el empleado a la lista de empleados
    
    return render_template('index.html', mensaje=f"Empleado {nombre} agregado correctamente.", empleados=empleados)
    # Renderiza la plantilla 'index.html' con un mensaje de éxito y la lista de empleados

@app.route('/actualizar_salario', methods=['POST'])
def actualizar_salario():
    nombre = request.form['nombre']  # Obtener nombre del formulario
    nuevo_salario = float(request.form['nuevo_salario'])  # Obtener nuevo salario del formulario
    
    for empleado in empleados:
        if empleado["nombre"] == nombre:
            empleado["salario"] = nuevo_salario
            # Actualizar el salario del empleado encontrado
            return render_template('index.html', mensaje=f"Salario de {nombre} actualizado correctamente.", empleados=empleados)
            # Renderiza la plantilla 'index.html' con un mensaje de éxito y la lista de empleados
    
    return render_template('index.html', mensaje=f"No se encontró ningún empleado con el nombre {nombre}.", empleados=empleados)
    # Renderiza la plantilla 'index.html' con un mensaje de error y la lista de empleados

@app.route('/mostrar_empleados')
def mostrar_empleados():
    return render_template('index.html', empleados=empleados)
    # Renderiza la plantilla 'index.html' y pasa la lista de empleados como argumento

if __name__ == '__main__':
    app.run()
    # Inicia la aplicación Flask